﻿using System;
using System.Collections.Generic;

namespace Avl_Dsw_uygulama
{
    // Düğüm Yapısı
    public class Node
    {
        public char Data;
        public Node Left, Right, Parent;
        public int Height;
        public int Frequency; // Erişim sayısı

        public Node(char data)
        {
            Data = data;
            Height = 1;
            Frequency = 0;
        }
    }

    // Ağaç Yönetim Sınıfı
    public class TreeManager
    {
        public Node Root;

        // Türkçe sıralama için basit yardımcı metot
        // (A < Ç < E < I < İ < K...)
        private int Compare(char c1, char c2)
        {
            string alfabe = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ";
            // Harfleri listedeki sırasına göre kıyaslar
            return alfabe.IndexOf(char.ToUpper(c1)).CompareTo(alfabe.IndexOf(char.ToUpper(c2)));
        }

        #region 1. ADIM: AVL (Ekleme ve Dengeleme)

        public void Insert(char key)
        {
            Root = InsertRec(Root, key);
        }

        private Node InsertRec(Node node, char key)
        {
            if (node == null) return new Node(key);

            // Ekleme İşlemi
            if (Compare(key, node.Data) < 0)
                node.Left = InsertRec(node.Left, key);
            else if (Compare(key, node.Data) > 0)
                node.Right = InsertRec(node.Right, key);
            else
                return node; // Aynı kayıt eklenmez

            // Yükseklik Güncelleme
            node.Height = 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));

            // Denge Kontrolü ve Dönüşler
            int balance = GetBalance(node);

            // Sol-Sol (LL) -> Sağa Dön
            if (balance > 1 && Compare(key, node.Left.Data) < 0)
                return RotateRight(node);

            // Sağ-Sağ (RR) -> Sola Dön
            if (balance < -1 && Compare(key, node.Right.Data) > 0)
                return RotateLeft(node);

            // Sol-Sağ (LR) -> Sola sonra Sağa
            if (balance > 1 && Compare(key, node.Left.Data) > 0)
            {
                node.Left = RotateLeft(node.Left);
                return RotateRight(node);
            }

            // Sağ-Sol (RL) -> Sağa sonra Sola
            if (balance < -1 && Compare(key, node.Right.Data) < 0)
            {
                node.Right = RotateRight(node.Right);
                return RotateLeft(node);
            }

            return node;
        }

        // Yardımcı AVL Metotları
        private int GetHeight(Node n) => (n == null) ? 0 : n.Height;
        private int GetBalance(Node n) => (n == null) ? 0 : GetHeight(n.Left) - GetHeight(n.Right);

        private Node RotateRight(Node y)
        {
            Node x = y.Left;
            Node T2 = x.Right;

            x.Right = y;
            y.Left = T2;

            UpdateHeight(y);
            UpdateHeight(x);

            // Ebeveynleri güncelle (Self-Adjusting için gerekli)
            UpdateParentLinks(x, y.Parent); // x artık y'nin yerinde
            UpdateParentLinks(y, x);        // y artık x'in çocuğu
            if (T2 != null) UpdateParentLinks(T2, y);

            return x;
        }

        private Node RotateLeft(Node x)
        {
            Node y = x.Right;
            Node T2 = y.Left;

            y.Left = x;
            x.Right = T2;

            UpdateHeight(x);
            UpdateHeight(y);

            // Ebeveynleri güncelle
            UpdateParentLinks(y, x.Parent);
            UpdateParentLinks(x, y);
            if (T2 != null) UpdateParentLinks(T2, x);

            return y;
        }

        private void UpdateHeight(Node n)
        {
            n.Height = 1 + Math.Max(GetHeight(n.Left), GetHeight(n.Right));
        }

        // Düğümün parent bilgisini güvenli şekilde günceller
        private void UpdateParentLinks(Node child, Node parent)
        {
            if (child != null) child.Parent = parent;
        }
        #endregion

        #region 2. ADIM: DSW Algoritması

        public void ApplyDSW()
        {
            // Omurga Oluştur: Her şeyi sağa yatır
            CreateBackbone();

            // Dengele: Sola dönüşlerle ağacı toparla
            BalanceBackbone();

            // Tüm ağacın parent bağlarını tazele (garanti olsun)
            FixAllParents(Root, null);
        }

        private void CreateBackbone()
        {
            Node gp = null; // GrandParent
            Node temp = Root;

            while (temp != null)
            {
                if (temp.Left != null)
                {
                    // Sola çocuk varsa, sağa döndür (Rotate Right)
                    Node child = temp.Left;
                    temp.Left = child.Right;
                    child.Right = temp;

                    if (gp == null) Root = child;
                    else gp.Right = child;

                    temp = child; // Başa dön, tekrar kontrol et
                }
                else
                {
                    gp = temp;
                    temp = temp.Right; // Sağa ilerle
                }
            }
        }

        private void BalanceBackbone()
        {
            // Düğüm sayısını bul
            int n = 0;
            Node p = Root;
            while (p != null) { n++; p = p.Right; }

            // İdeal formül: m = n - (2^k - 1)
            int m = (int)Math.Pow(2, Math.Floor(Math.Log(n + 1, 2))) - 1;

            MakeDSWRotations(n - m);
            while (m > 1)
            {
                m /= 2;
                MakeDSWRotations(m);
            }
        }

        private void MakeDSWRotations(int count)
        {
            Node gp = null;
            Node temp = Root;

            for (int i = 0; i < count; i++)
            {
                if (temp == null || temp.Right == null) break;

                Node child = temp.Right;

                // Sola Dönüş (Rotate Left - DSW stili)
                temp.Right = child.Left;
                child.Left = temp;

                if (gp == null) Root = child;
                else gp.Right = child;

                gp = child;
                temp = gp.Right;
            }
        }
        #endregion

        #region 3. ADIM: Self-Adjusting (Frekans)

        public void Search(char key)
        {
            Console.Write($"'{key}' aranıyor... ");
            Node found = Find(Root, key);

            if (found != null)
            {
                found.Frequency++;
                Console.WriteLine($"Bulundu. Frekans: {found.Frequency}. Yukarı taşınıyor.");
                AdjustUpwards(found);
            }
            else
            {
                Console.WriteLine("Bulunamadı.");
            }
        }

        private Node Find(Node n, char key)
        {
            if (n == null) return null;
            if (key == n.Data) return n;
            return (Compare(key, n.Data) < 0) ? Find(n.Left, key) : Find(n.Right, key);
        }

        private void AdjustUpwards(Node node)
        {
            // Eğer node, parent'ından daha popülerse yer değiştir
            while (node.Parent != null && node.Frequency > node.Parent.Frequency)
            {
                Node parent = node.Parent;

                // Node, Parent'ın solunda mı sağında mı?
                if (parent.Left == node)
                {
                    // Sağa döndürerek node'u yukarı çıkar
                    Node newRoot = RotateRight(parent);
                    if (parent == Root) Root = newRoot;
                    else
                    {
                        // Büyük dede (Grandparent) bağlantısını düzelt
                        if (newRoot.Parent.Left == parent) newRoot.Parent.Left = newRoot;
                        else newRoot.Parent.Right = newRoot;
                    }
                }
                else
                {
                    // Sola döndürerek node'u yukarı çıkar
                    Node newRoot = RotateLeft(parent);
                    if (parent == Root) Root = newRoot;
                    else
                    {
                        if (newRoot.Parent.Left == parent) newRoot.Parent.Left = newRoot;
                        else newRoot.Parent.Right = newRoot;
                    }
                }
            }
        }

        // Yardımcı: Tüm parent bağlarını düzeltir
        private void FixAllParents(Node node, Node parent)
        {
            if (node == null) return;
            node.Parent = parent;
            FixAllParents(node.Left, node);
            FixAllParents(node.Right, node);
        }
        #endregion

        #region Yazdırma İşlemleri

        public void PrintTree()
        {
            if (Root == null) { Console.WriteLine("Boş Ağaç"); return; }
            PrintPretty(Root, "", true);
        }

        private void PrintPretty(Node node, string indent, bool isLast)
        {
            if (node != null)
            {
                Console.Write(indent);
                Console.Write(isLast ? "└─ " : "├─ ");
                Console.WriteLine($"{node.Data} (F:{node.Frequency})");

                // Rekürsif yazdırma
                PrintPretty(node.Left, indent + (isLast ? "   " : "|  "), false);
                PrintPretty(node.Right, indent + (isLast ? "   " : "|  "), true);
            }
        }
        #endregion
    }

    class Program
    {
        static void Main(string[] args)
        {
            TreeManager tree = new TreeManager();
            char[] veri = { 'S', 'E', 'L', 'İ', 'M', 'K', 'A', 'Ç', 'T', 'I' };

            Console.WriteLine("=== 1. AVL AĞACI OLUŞTURMA ===");
            foreach (char c in veri) tree.Insert(c);
            tree.PrintTree();

            Console.WriteLine("\n=== 2. DSW İLE DENGELEME ===");
            tree.ApplyDSW();
            tree.PrintTree();

            Console.WriteLine("\n=== 3. SELF-ADJUSTING (Frekans Testi) ===");
            // 'A' ve 'K' harflerini popüler yapalım
            tree.Search('A'); tree.Search('A'); // A: 2 kere
            tree.Search('K'); tree.Search('K'); tree.Search('K'); // K: 3 kere (En tepeye çıkmalı)

            Console.WriteLine("\nSon Durum:");
            tree.PrintTree();

            Console.ReadKey();
        }
    }
}